package com.cloudwebrtc.webrtc;

/**
 * Radio Géniale : accès au son brut du micro capté par WebRTC (PCM 16 bits),
 * utilisé par l'appli pour l'enregistrement MP3 pendant le direct.
 */
public final class RgCaptureAudio {
  private RgCaptureAudio() {}

  public interface Ecouteur {
    /** data = PCM 16 bits little-endian, entrelacé si channels == 2. */
    void onEchantillons(byte[] data, int sampleRate, int channels);
  }

  public static volatile Ecouteur ecouteur;
}
