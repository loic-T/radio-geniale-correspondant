package com.cloudwebrtc.vdon_flutter

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import androidx.core.content.FileProvider
import com.cloudwebrtc.webrtc.RgCaptureAudio
import com.cloudwebrtc.webrtc.audio.AudioUtils
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors

/**
 * Radio Géniale : enregistrement MP3 mono 128 kb/s du micro pendant le direct.
 * Le son vient directement du module audio WebRTC (pas de second accès au
 * micro). L'enregistrement est mis en pause quand le micro est coupé.
 */
object Enregistreur {
    private const val TAG = "RadioGenialeRec"
    private const val KBPS = 128
    private const val SIGNAL = "org.thoughtcrime.securesms"
    private const val PROTON_MAIL = "ch.protonmail.android"
    const val EMAIL_RADIO = "radiogeniale@proton.me"

    private val executeur = Executors.newSingleThreadExecutor()

    @Volatile private var actif = false
    @Volatile private var enPause = false

    // Utilisés uniquement sur le fil de l'exécuteur
    private var fichier: File? = null
    private var sortie: FileOutputStream? = null
    private var encodeur = 0L
    private var canaux = 1
    private var tauxEch = 48000
    private var echantillons = 0L
    private var tampon = ByteArray(16384)

    // Enregistrement « sans direct » : micro ouvert directement par l'appli
    @Volatile private var audioRecord: AudioRecord? = null
    private var filLecture: Thread? = null

    /** Dernier enregistrement terminé (pour le partage). */
    private var dernierFichier: File? = null
    private var dernierUri: Uri? = null

    fun demarrer(context: Context, nomFichier: String): Boolean {
        if (actif) return true
        val dossier = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: context.filesDir
        dossier.mkdirs()
        val f = File(dossier, nomFichier)
        executeur.submit(Runnable {
            fichier = f
            sortie = FileOutputStream(f)
            encodeur = 0L
            echantillons = 0L
        }).get()
        enPause = false
        actif = true
        RgCaptureAudio.ecouteur = RgCaptureAudio.Ecouteur { data, sampleRate, channels ->
            if (actif && !enPause) {
                executeur.execute { encoder(data, sampleRate, channels) }
            }
        }
        Log.i(TAG, "Enregistrement démarré : ${f.absolutePath}")
        return true
    }

    /**
     * Enregistrement sans direct : ouvre le micro avec le même mode et le
     * même micro que le direct (écran « Micro » de l'appli).
     */
    @SuppressLint("MissingPermission")
    fun demarrerAutonome(
        context: Context, nomFichier: String, mode: String, microId: String?
    ): Boolean {
        if (actif) return true
        val taux = 48000
        val source = when (mode) {
            "unprocessed" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
                MediaRecorder.AudioSource.UNPROCESSED else MediaRecorder.AudioSource.MIC
            "camcorder" -> MediaRecorder.AudioSource.CAMCORDER
            "voiceRecognition" -> MediaRecorder.AudioSource.VOICE_RECOGNITION
            "voiceCommunication" -> MediaRecorder.AudioSource.VOICE_COMMUNICATION
            else -> MediaRecorder.AudioSource.MIC
        }
        val canalEntree = if (mode == "micStereo") AudioFormat.CHANNEL_IN_STEREO
        else AudioFormat.CHANNEL_IN_MONO
        val nbCanaux = if (mode == "micStereo") 2 else 1
        val tailleMin = AudioRecord.getMinBufferSize(
            taux, canalEntree, AudioFormat.ENCODING_PCM_16BIT
        )
        if (tailleMin <= 0) return false
        val rec = try {
            AudioRecord(source, taux, canalEntree, AudioFormat.ENCODING_PCM_16BIT,
                maxOf(tailleMin, taux * nbCanaux * 2 / 5))
        } catch (e: Exception) {
            Log.e(TAG, "Micro inaccessible", e)
            return false
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return false
        }
        // Micro choisi dans l'écran « Micro »
        if (microId != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.getDevices(AudioManager.GET_DEVICES_INPUTS)
                    .firstOrNull { d: AudioDeviceInfo -> AudioUtils.getAudioDeviceId(d) == microId }
                    ?.let { rec.setPreferredDevice(it) }
            } catch (e: Exception) {
                Log.w(TAG, "Micro préféré non appliqué", e)
            }
        }

        val dossier = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: context.filesDir
        dossier.mkdirs()
        val f = File(dossier, nomFichier)
        executeur.submit(Runnable {
            fichier = f
            sortie = FileOutputStream(f)
            encodeur = 0L
            echantillons = 0L
        }).get()
        enPause = false
        actif = true
        audioRecord = rec
        try {
            rec.startRecording()
        } catch (e: Exception) {
            Log.e(TAG, "Démarrage du micro impossible", e)
            actif = false
            audioRecord = null
            rec.release()
            return false
        }
        // Lecture par blocs de 10 ms, encodés sur l'exécuteur
        val bloc = taux / 100 * nbCanaux * 2
        filLecture = Thread {
            val buffer = ByteArray(bloc)
            while (actif && audioRecord === rec) {
                val n = try { rec.read(buffer, 0, bloc) } catch (e: Exception) { -1 }
                if (n < 0) break
                if (n > 0 && !enPause) {
                    val copie = buffer.copyOf(n)
                    executeur.execute { encoder(copie, taux, nbCanaux) }
                }
            }
        }.apply {
            name = "RadioGenialeEnregistrement"
            start()
        }
        Log.i(TAG, "Enregistrement sans direct démarré : ${f.absolutePath} (mode $mode)")
        return true
    }

    fun pause(pause: Boolean) {
        enPause = pause
    }

    private fun encoder(data: ByteArray, sampleRate: Int, channels: Int) {
        val out = sortie ?: return
        val ch = if (channels >= 2) 2 else 1
        if (encodeur == 0L) {
            canaux = ch
            tauxEch = sampleRate
            encodeur = Mp3Encodeur.nativeInit(sampleRate, ch, KBPS)
            if (encodeur == 0L) {
                Log.e(TAG, "Encodeur MP3 non initialisé")
                return
            }
        }
        if (ch != canaux || sampleRate != tauxEch) return
        val shorts = ShortArray(data.size / 2)
        ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shorts)
        val parCanal = shorts.size / ch
        val besoin = (parCanal * 5 / 4) + 7200
        if (tampon.size < besoin) tampon = ByteArray(besoin)
        val n = Mp3Encodeur.nativeEncode(encodeur, shorts, parCanal, ch, tampon)
        if (n > 0) out.write(tampon, 0, n)
        echantillons += parCanal
    }

    /** Arrête l'enregistrement et renvoie ses infos (durée, taille, emplacement). */
    fun arreter(context: Context): Map<String, Any?> {
        if (!actif && fichier == null) return mapOf("ok" to false)
        actif = false
        RgCaptureAudio.ecouteur = null
        audioRecord?.let { rec ->
            audioRecord = null
            try { rec.stop() } catch (e: Exception) { Log.w(TAG, "stop micro", e) }
            try { filLecture?.join(1000) } catch (e: Exception) { Log.w(TAG, "join", e) }
            filLecture = null
            try { rec.release() } catch (e: Exception) { Log.w(TAG, "release micro", e) }
        }
        val infos: Map<String, Any?> = executeur.submit(java.util.concurrent.Callable<Map<String, Any?>> {
            val f = fichier
            try {
                if (encodeur != 0L) {
                    val n = Mp3Encodeur.nativeFlush(encodeur, tampon)
                    if (n > 0) sortie?.write(tampon, 0, n)
                    Mp3Encodeur.nativeClose(encodeur)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Fin d'encodage", e)
            }
            try { sortie?.close() } catch (e: Exception) { Log.w(TAG, "Fermeture", e) }
            val duree = if (tauxEch > 0) echantillons / tauxEch else 0L
            val vide = encodeur == 0L
            encodeur = 0L
            sortie = null
            fichier = null
            mapOf(
                "fichier" to f,
                "duree" to duree,
                "vide" to vide
            )
        }).get()

        val f = infos["fichier"] as File?
        if (f == null || infos["vide"] == true) {
            f?.delete()
            return mapOf("ok" to false)
        }
        dernierFichier = f
        dernierUri = copierDansMusique(context, f)
        return mapOf(
            "ok" to true,
            "nom" to f.name,
            "duree" to (infos["duree"] as Long).toInt(),
            "octets" to f.length().toInt(),
            "public" to (dernierUri != null)
        )
    }

    /** Android 10+ : copie le MP3 dans Musique › Radio Géniale (visible partout). */
    private fun copierDansMusique(context: Context, f: File): Uri? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return try {
            val valeurs = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, f.name)
                put(MediaStore.Audio.Media.MIME_TYPE, "audio/mpeg")
                put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/Radio Géniale")
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, valeurs)
                ?: return null
            resolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
            valeurs.clear()
            valeurs.put(MediaStore.Audio.Media.IS_PENDING, 0)
            resolver.update(uri, valeurs, null, null)
            uri
        } catch (e: Exception) {
            Log.w(TAG, "Copie dans Musique impossible", e)
            null
        }
    }

    private fun installe(context: Context, paquet: String): Boolean =
        try {
            context.packageManager.getPackageInfo(paquet, 0)
            true
        } catch (e: Exception) {
            false
        }

    /** Partage le dernier enregistrement par Signal ou par mail. */
    fun partager(activity: Activity, mode: String, sujet: String, texte: String): Boolean {
        val f = dernierFichier ?: return false
        val uri = dernierUri ?: FileProvider.getUriForFile(
            activity, activity.packageName + ".fichiers", f
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "audio/mpeg"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri(f.name, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        when (mode) {
            "signal" -> {
                intent.putExtra(Intent.EXTRA_TEXT, texte)
                if (installe(activity, SIGNAL)) intent.setPackage(SIGNAL)
            }
            else -> {
                intent.putExtra(Intent.EXTRA_EMAIL, arrayOf(EMAIL_RADIO))
                intent.putExtra(Intent.EXTRA_SUBJECT, sujet)
                intent.putExtra(Intent.EXTRA_TEXT, texte)
                if (installe(activity, PROTON_MAIL)) intent.setPackage(PROTON_MAIL)
            }
        }
        return try {
            if (intent.`package` != null) {
                activity.startActivity(intent)
            } else {
                activity.startActivity(Intent.createChooser(intent, "Envoyer l'enregistrement"))
            }
            true
        } catch (e: Exception) {
            Log.w(TAG, "Partage impossible", e)
            try {
                intent.setPackage(null)
                activity.startActivity(Intent.createChooser(intent, "Envoyer l'enregistrement"))
                true
            } catch (e2: Exception) {
                false
            }
        }
    }
}
