package com.cloudwebrtc.vdon_flutter

/** Radio Géniale : encodeur MP3 (LAME, bibliothèque native « mp3encodeur »). */
object Mp3Encodeur {
    init {
        System.loadLibrary("mp3encodeur")
    }

    @JvmStatic external fun nativeInit(sampleRate: Int, channels: Int, kbps: Int): Long
    @JvmStatic external fun nativeEncode(
        handle: Long, pcm: ShortArray, samplesPerChannel: Int, channels: Int, out: ByteArray
    ): Int
    @JvmStatic external fun nativeFlush(handle: Long, out: ByteArray): Int
    @JvmStatic external fun nativeClose(handle: Long)
}
