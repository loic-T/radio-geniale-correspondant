# Radio Géniale : encodeur MP3 (LAME 3.99, licence LGPL) pour l'enregistrement
cmake_minimum_required(VERSION 3.18)
project(mp3encodeur C)

file(GLOB LAME_SOURCES ${CMAKE_CURRENT_SOURCE_DIR}/lame/*.c)

add_library(mp3encodeur SHARED
        mp3_encodeur.c
        ${LAME_SOURCES})

target_include_directories(mp3encodeur PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/lame)
target_compile_definitions(mp3encodeur PRIVATE STDC_HEADERS HAVE_STDINT_H HAVE_LIMITS_H HAVE_INTTYPES_H)
target_compile_options(mp3encodeur PRIVATE -O2 -w)
target_link_libraries(mp3encodeur m log)
