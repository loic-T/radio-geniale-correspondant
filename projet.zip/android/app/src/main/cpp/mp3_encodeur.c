// Radio Géniale : pont JNI vers l'encodeur MP3 LAME.
#include <jni.h>
#include <stdlib.h>
#include <stdint.h>
#include "lame.h"

JNIEXPORT jlong JNICALL
Java_com_cloudwebrtc_vdon_1flutter_Mp3Encodeur_nativeInit(
        JNIEnv *env, jclass cls, jint sampleRate, jint channels, jint kbps) {
    lame_t l = lame_init();
    if (l == NULL) return 0;
    lame_set_in_samplerate(l, sampleRate);
    lame_set_num_channels(l, channels);
    lame_set_out_samplerate(l, sampleRate);
    lame_set_mode(l, MONO);          // sortie mono (entrée stéréo mélangée)
    lame_set_brate(l, kbps);         // débit constant
    lame_set_VBR(l, vbr_off);
    lame_set_quality(l, 5);
    if (lame_init_params(l) < 0) {
        lame_close(l);
        return 0;
    }
    return (jlong) (intptr_t) l;
}

JNIEXPORT jint JNICALL
Java_com_cloudwebrtc_vdon_1flutter_Mp3Encodeur_nativeEncode(
        JNIEnv *env, jclass cls, jlong handle, jshortArray pcm,
        jint samplesPerChannel, jint channels, jbyteArray out) {
    lame_t l = (lame_t) (intptr_t) handle;
    if (l == NULL) return -1;
    jshort *p = (*env)->GetShortArrayElements(env, pcm, NULL);
    jbyte *o = (*env)->GetByteArrayElements(env, out, NULL);
    jsize taille = (*env)->GetArrayLength(env, out);
    int n;
    if (channels == 2) {
        n = lame_encode_buffer_interleaved(l, p, samplesPerChannel,
                                           (unsigned char *) o, taille);
    } else {
        n = lame_encode_buffer(l, p, p, samplesPerChannel,
                               (unsigned char *) o, taille);
    }
    (*env)->ReleaseShortArrayElements(env, pcm, p, JNI_ABORT);
    (*env)->ReleaseByteArrayElements(env, out, o, 0);
    return n;
}

JNIEXPORT jint JNICALL
Java_com_cloudwebrtc_vdon_1flutter_Mp3Encodeur_nativeFlush(
        JNIEnv *env, jclass cls, jlong handle, jbyteArray out) {
    lame_t l = (lame_t) (intptr_t) handle;
    if (l == NULL) return -1;
    jbyte *o = (*env)->GetByteArrayElements(env, out, NULL);
    jsize taille = (*env)->GetArrayLength(env, out);
    int n = lame_encode_flush(l, (unsigned char *) o, taille);
    (*env)->ReleaseByteArrayElements(env, out, o, 0);
    return n;
}

JNIEXPORT void JNICALL
Java_com_cloudwebrtc_vdon_1flutter_Mp3Encodeur_nativeClose(
        JNIEnv *env, jclass cls, jlong handle) {
    lame_t l = (lame_t) (intptr_t) handle;
    if (l != NULL) lame_close(l);
}
