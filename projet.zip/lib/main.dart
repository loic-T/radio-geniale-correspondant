// Radio Géniale – Correspondant
// Application de prise d'antenne à distance pour les correspondants de
// Radio Géniale. Basée sur l'application open source VDO.Ninja
// (https://github.com/steveseguin/vdon_flutter, licence GPL-3.0).

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';

import 'radio/accueil_screen.dart';
import 'radio/theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Micro « brut » pour les correspondants : on désactive les traitements
  // audio matériels du téléphone (réduction de bruit / porte de bruit,
  // annulation d'écho, mode « appel vocal »). Doit être fait avant toute
  // autre utilisation de WebRTC.
  try {
    await WebRTC.initialize(options: {
      'bypassVoiceProcessing': true,
    });
  } catch (e) {
    debugPrint('Initialisation WebRTC : $e');
  }

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    statusBarBrightness: Brightness.dark,
    systemNavigationBarColor: RgColors.fond,
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  runApp(const RadioGenialeApp());
}

class RadioGenialeApp extends StatelessWidget {
  const RadioGenialeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Radio Géniale',
      debugShowCheckedModeBanner: false,
      theme: rgTheme(),
      home: const AccueilScreen(),
    );
  }
}
