import 'dart:async';
import 'dart:io' show Platform;

import 'package:audio_session/audio_session.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:just_audio/just_audio.dart';

import 'arriere_plan.dart';
import 'titre_icy.dart';

/// Flux en direct de Radio Géniale (le même que sur le site).
const String urlFluxRadio = 'https://stream1.world-stream.net/radiogeniale/stream';

/// User-Agent de navigateur (2e tentative) : certains serveurs de flux
/// refusent les lecteurs inconnus alors qu'ils acceptent Chrome.
const String _uaNavigateur =
    'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 '
    '(KHTML, like Gecko) Chrome/130.0 Mobile Safari/537.36';

enum EtatLecteur { arrete, chargement, lecture, erreur }

/// Lecteur du direct, partagé par toute l'application.
class LecteurRadio extends ChangeNotifier {
  LecteurRadio._() {
    if (Platform.isAndroid) {
      _canalRadio.setMethodCallHandler((call) async {
        if (call.method == 'etat') {
          final args = Map<String, dynamic>.from(call.arguments as Map);
          _surEtatNatif(args['etat'] as String?, args['detail'] as String?);
        }
        return null;
      });
    }
  }
  static final LecteurRadio instance = LecteurRadio._();

  /// Android : lecteur natif (MediaPlayer) hébergé dans le service de
  /// premier plan. Tentative 0 = natif ; 1 et 2 = just_audio en secours.
  static const _canalService = MethodChannel('radiogeniale/micservice');
  static const _canalRadio = MethodChannel('radiogeniale/radio');
  Timer? _minuteurTitre;

  AudioPlayer? _player;
  final List<StreamSubscription<dynamic>> _abonnements = [];
  EtatLecteur _etat = EtatLecteur.arrete;
  bool _veutJouer = false;
  bool _aDemarre = false;
  int _tentative = 0;

  EtatLecteur get etat => _etat;

  /// Détail technique de la dernière erreur (affiché pour le diagnostic).
  String? derniereErreur;

  /// Titre en cours d'après les métadonnées du flux (ex. « MANIFESTATION -
  /// 24 octobre 2026 - Paris (rediffusion) »), null si inconnu.
  String? titre;

  bool get actif =>
      _etat == EtatLecteur.lecture || _etat == EtatLecteur.chargement;

  void _changerEtat(EtatLecteur e) {
    if (_etat == e) return;
    _etat = e;
    notifyListeners();
  }

  Future<void> _libererPlayer() async {
    for (final a in _abonnements) {
      await a.cancel();
    }
    _abonnements.clear();
    final p = _player;
    _player = null;
    if (p != null) {
      try {
        await p.dispose();
      } catch (_) {}
    }
  }

  /// Crée un lecteur. Tentative 1 : lecteur standard (sans proxy local).
  /// Tentative 2 : même flux en se présentant comme un navigateur.
  AudioPlayer _creerPlayer(int tentative) {
    final player =
        tentative == 1 ? AudioPlayer() : AudioPlayer(userAgent: _uaNavigateur);

    _abonnements.add(player.playerStateStream.listen((s) {
      if (tentative != _tentative) return; // ancien lecteur
      if (!_veutJouer) {
        _changerEtat(EtatLecteur.arrete);
      } else if (s.processingState == ProcessingState.completed) {
        // Le direct s'est interrompu côté serveur.
        _veutJouer = false;
        _changerEtat(EtatLecteur.arrete);
        ArrierePlan.arreterRadio();
      } else if (s.playing && s.processingState == ProcessingState.ready) {
        _aDemarre = true;
        _changerEtat(EtatLecteur.lecture);
        _demarrerSuiviTitre();
      } else if (_aDemarre && !s.playing) {
        // Mise en pause par le système (appel entrant, casque débranché…).
        _veutJouer = false;
        _changerEtat(EtatLecteur.arrete);
        ArrierePlan.arreterRadio();
      } else {
        _changerEtat(EtatLecteur.chargement);
      }
    }, onError: (Object e, StackTrace st) {
      if (tentative == _tentative) _surErreur(e);
    }));

    // Métadonnées ICY envoyées par le serveur (titre de l'émission).
    _abonnements.add(player.icyMetadataStream.listen((meta) {
      final t = meta?.info?.title?.trim();
      if (t != null && t.isNotEmpty && t != titre) {
        titre = t;
        notifyListeners();
      }
    }, onError: (Object e, StackTrace st) {}));

    return player;
  }

  /// Erreur pendant la lecture : on essaie la méthode suivante, sinon on
  /// affiche le détail.
  void _surErreur(Object e) {
    final detail = 'tentative $_tentative : $e';
    derniereErreur =
        derniereErreur == null ? detail : '$derniereErreur\n$detail';
    if (_veutJouer && !_aDemarre && _tentative < 2) {
      _lancer(_tentative + 1);
      return;
    }
    _veutJouer = false;
    _changerEtat(EtatLecteur.erreur);
    ArrierePlan.arreterRadio();
  }

  Future<void> ecouter() async {
    _veutJouer = true;
    derniereErreur = null;
    _changerEtat(EtatLecteur.chargement);
    try {
      final session = await AudioSession.instance;
      await session.configure(const AudioSessionConfiguration.music());
      await session.setActive(true);
    } catch (e) {
      debugPrint('Session audio : $e');
    }
    unawaited(rafraichirTitre());
    if (Platform.isAndroid) {
      await _lancerNatif();
    } else {
      await _lancer(1);
    }
  }

  Future<void> _lancerNatif() async {
    _tentative = 0;
    _aDemarre = false;
    await _libererPlayer();
    try {
      await _canalService.invokeMethod('radioPlay', {
        'url': urlFluxRadio,
        'titre': 'Radio Géniale',
        'texte': 'À l\'écoute en direct. Touchez pour revenir à l\'appli.',
      });
    } catch (e) {
      _surEtatNatif('erreur', '$e');
    }
  }

  void _surEtatNatif(String? etat, String? detail) {
    if (_tentative != 0) return; // le secours just_audio a pris le relais
    switch (etat) {
      case 'lecture':
        if (!_veutJouer) {
          _canalService.invokeMethod('radioStop');
          return;
        }
        _aDemarre = true;
        _changerEtat(EtatLecteur.lecture);
        _demarrerSuiviTitre();
        break;
      case 'erreur':
        final d = 'lecteur Android : ${detail ?? 'inconnu'}';
        derniereErreur = derniereErreur == null ? d : '$derniereErreur\n$d';
        if (_veutJouer && !_aDemarre) {
          _lancer(1); // secours : lecteur just_audio
        } else {
          _veutJouer = false;
          _changerEtat(EtatLecteur.erreur);
        }
        break;
      case 'arrete':
        _veutJouer = false;
        _changerEtat(EtatLecteur.arrete);
        break;
    }
  }

  /// Met à jour le titre de l'émission (lu dans les métadonnées du flux).
  Future<void> rafraichirTitre() async {
    final t = await lireTitreIcy(urlFluxRadio);
    if (t != null && t != titre) {
      titre = t;
      notifyListeners();
    }
  }

  void _demarrerSuiviTitre() {
    _minuteurTitre?.cancel();
    _minuteurTitre = Timer.periodic(const Duration(seconds: 30), (_) {
      if (_etat == EtatLecteur.lecture) {
        rafraichirTitre();
      } else {
        _minuteurTitre?.cancel();
      }
    });
  }

  Future<void> _lancer(int tentative) async {
    _tentative = tentative;
    _aDemarre = false;
    await _libererPlayer();
    if (!_veutJouer) return;
    try {
      final player = _creerPlayer(tentative);
      _player = player;
      // On recharge l'URL à chaque fois pour repartir du direct.
      await player.setUrl(urlFluxRadio);
      if (!_veutJouer || tentative != _tentative) return;
      await ArrierePlan.demarrerRadio();
      // play() ne se termine qu'à l'arrêt : on ne l'attend pas.
      unawaited(player.play().catchError((Object e) {
        if (tentative == _tentative) _surErreur(e);
      }));
    } catch (e) {
      debugPrint('Lecture impossible (tentative $tentative) : $e');
      if (tentative == _tentative) _surErreur(e);
    }
  }

  Future<void> arreter() async {
    _veutJouer = false;
    _minuteurTitre?.cancel();
    if (Platform.isAndroid) {
      try {
        await _canalService.invokeMethod('radioStop');
      } catch (_) {}
    }
    try {
      await _player?.stop();
    } catch (_) {}
    _changerEtat(EtatLecteur.arrete);
    await ArrierePlan.arreterRadio();
  }
}
