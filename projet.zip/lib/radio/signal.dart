import 'dart:io' show Platform;

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

/// Ouvre Signal en écran partagé à côté de l'appli (Android uniquement) et
/// indique si l'appli est actuellement en écran partagé.
class SignalApp {
  static const _canal = MethodChannel('radiogeniale/micservice');
  static const _canalFenetre = MethodChannel('radiogeniale/fenetre');

  static bool get disponible => Platform.isAndroid;

  /// Vrai quand l'appli est en écran partagé (mis à jour en direct).
  static final ValueNotifier<bool> ecranPartage = ValueNotifier(false);
  static bool _ecoute = false;

  /// À appeler une fois (ex. à l'ouverture de l'écran de direct).
  static Future<void> surveillerEcranPartage() async {
    if (!disponible) return;
    if (!_ecoute) {
      _ecoute = true;
      _canalFenetre.setMethodCallHandler((call) async {
        if (call.method == 'multiFenetre') {
          ecranPartage.value = call.arguments == true;
        }
        return null;
      });
    }
    try {
      ecranPartage.value =
          await _canalFenetre.invokeMethod<bool>('estMultiFenetre') ?? false;
    } catch (_) {}
  }

  /// Renvoie true si Signal a été ouvert, false s'il n'est pas installé
  /// (le Play Store s'ouvre alors sur sa fiche).
  static Future<bool> ouvrirACote() async {
    try {
      final r = await _canal.invokeMethod<String>('signalACote');
      return r == 'ok';
    } catch (_) {
      return false;
    }
  }
}
