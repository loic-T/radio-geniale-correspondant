import 'package:flutter/material.dart';

import 'reglages.dart';
import 'theme.dart';

/// Écran « Réglages » du correspondant : traitements audio du micro.
/// [lectureSeule] : affiché pendant un direct (les changements ne peuvent
/// s'appliquer qu'au prochain direct).
class ReglagesScreen extends StatefulWidget {
  const ReglagesScreen({super.key, this.lectureSeule = false});

  final bool lectureSeule;

  @override
  State<ReglagesScreen> createState() => _ReglagesScreenState();
}

class _ReglagesScreenState extends State<ReglagesScreen> {
  Future<void> _changer(void Function() modif) async {
    setState(modif);
    await ReglagesAudio.enregistrer();
  }

  Widget _interrupteur({
    required String titre,
    required String parametreWeb,
    required String explication,
    required bool valeur,
    required ValueChanged<bool> onChanged,
  }) {
    return SwitchListTile(
      value: valeur,
      onChanged: widget.lectureSeule ? null : onChanged,
      activeColor: RgColors.fond,
      activeTrackColor: RgColors.texte,
      title: Text(titre,
          style: const TextStyle(
              color: RgColors.texte, fontWeight: FontWeight.bold)),
      subtitle: Padding(
        padding: const EdgeInsets.only(top: 4),
        child: Text(
          '$explication\nPage web : $parametreWeb',
          style: const TextStyle(color: Colors.white70, fontSize: 13),
        ),
      ),
      isThreeLine: true,
    );
  }

  Widget _info(String titre, String valeur) {
    return ListTile(
      dense: true,
      title: Text(titre, style: const TextStyle(color: RgColors.texte)),
      trailing: Text(valeur, style: const TextStyle(color: Colors.white70)),
    );
  }

  Widget _section(String titre) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 4),
        child: Text(titre.toUpperCase(),
            style: const TextStyle(
                color: RgColors.fondTertiaire,
                fontSize: 13,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.2)),
      );

  @override
  Widget build(BuildContext context) {
    final redemarrageNecessaire = ReglagesAudio.traitementTelephone !=
        ReglagesAudio.traitementTelephoneActif;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: RgColors.fond,
        foregroundColor: RgColors.texte,
        elevation: 0,
        title: const Text('Réglages du micro'),
      ),
      body: SafeArea(
        child: ListView(
          children: [
            if (widget.lectureSeule)
              Container(
                margin: const EdgeInsets.all(16),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: RgColors.fondSecondaire,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Text(
                  'Direct en cours : les réglages sont affichés pour '
                  'information. Pour les modifier, terminez le direct puis '
                  'ouvrez les réglages depuis l\'écran de connexion.',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            _section('Traitements du son'),
            _interrupteur(
              titre: 'Réduction de bruit',
              parametreWeb: ReglagesAudio.reductionBruit ? 'dn=1' : 'dn=0',
              explication: 'Atténue les bruits de fond. Peut couper les sons '
                  'faibles (effet « noise gate »).',
              valeur: ReglagesAudio.reductionBruit,
              onChanged: (v) => _changer(() => ReglagesAudio.reductionBruit = v),
            ),
            _interrupteur(
              titre: 'Annulation d\'écho',
              parametreWeb: ReglagesAudio.annulationEcho ? 'aec=1' : 'aec=0',
              explication: 'Utile seulement si le téléphone diffuse du son '
                  'en même temps (retour antenne sur le haut-parleur).',
              valeur: ReglagesAudio.annulationEcho,
              onChanged: (v) => _changer(() => ReglagesAudio.annulationEcho = v),
            ),
            _interrupteur(
              titre: 'Gain automatique',
              parametreWeb: ReglagesAudio.gainAuto ? 'agc=1' : 'agc=0',
              explication: 'Monte ou baisse le volume du micro tout seul. '
                  'Pratique si vous parlez loin du téléphone.',
              valeur: ReglagesAudio.gainAuto,
              onChanged: (v) => _changer(() => ReglagesAudio.gainAuto = v),
            ),
            _interrupteur(
              titre: 'Traitement vocal du téléphone',
              parametreWeb: 'pas d\'équivalent (spécifique à l\'appli)',
              explication: 'Mode « appel téléphonique » d\'Android / iOS, '
                  'qui ajoute sa propre réduction de bruit. Désactivé = '
                  'son brut du micro. Pris en compte au prochain lancement '
                  'de l\'appli.',
              valeur: ReglagesAudio.traitementTelephone,
              onChanged: (v) =>
                  _changer(() => ReglagesAudio.traitementTelephone = v),
            ),
            if (redemarrageNecessaire)
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 4, 16, 0),
                child: Text(
                  '⚠ Fermez complètement l\'appli puis rouvrez-la pour '
                  'appliquer le traitement vocal du téléphone.',
                  style: TextStyle(color: Colors.amberAccent),
                ),
              ),
            _section('Fixe'),
            _info('Son', 'Mono (monomic)'),
            _info('Vidéo', 'Désactivée (vd=0)'),
            _info('Noise gate', 'Aucun (ng=0)'),
            _info('Serveur', 'vdo.ninja'),
            if (!widget.lectureSeule) ...[
              const SizedBox(height: 16),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: OutlinedButton(
                  onPressed: ReglagesAudio.parDefaut
                      ? null
                      : () async {
                          await ReglagesAudio.reinitialiser();
                          if (mounted) setState(() {});
                        },
                  style: OutlinedButton.styleFrom(
                    foregroundColor: RgColors.texte,
                    side: const BorderSide(color: RgColors.texte),
                  ),
                  child: const Text('Rétablir les réglages Radio Géniale'),
                ),
              ),
            ],
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}
