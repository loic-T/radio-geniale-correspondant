import 'package:shared_preferences/shared_preferences.dart';

import '../src/call_sample/signaling.dart' as sig;

/// Réglages audio du correspondant, mémorisés sur le téléphone.
/// Valeurs par défaut = celles de la page web
/// (&monomic&ng=0&aec=0&dn=0&agc=0).
class ReglagesAudio {
  static const _cleEcho = 'rg_aec';
  static const _cleBruit = 'rg_dn';
  static const _cleGain = 'rg_agc';
  static const _cleTelephone = 'rg_traitement_telephone';

  /// Annulation d'écho (aec)
  static bool annulationEcho = false;

  /// Réduction de bruit (dn) — c'est elle qui fait l'effet « noise gate »
  static bool reductionBruit = false;

  /// Gain automatique (agc)
  static bool gainAuto = false;

  /// Traitement vocal du téléphone (mode « appel » d'Android / iOS).
  /// Pris en compte au prochain lancement de l'appli.
  static bool traitementTelephone = false;

  /// Valeur de [traitementTelephone] utilisée au lancement en cours.
  static bool traitementTelephoneActif = false;

  static Future<void> charger() async {
    try {
      final p = await SharedPreferences.getInstance();
      annulationEcho = p.getBool(_cleEcho) ?? false;
      reductionBruit = p.getBool(_cleBruit) ?? false;
      gainAuto = p.getBool(_cleGain) ?? false;
      traitementTelephone = p.getBool(_cleTelephone) ?? false;
    } catch (_) {}
    traitementTelephoneActif = traitementTelephone;
    _appliquer();
  }

  static Future<void> enregistrer() async {
    _appliquer();
    try {
      final p = await SharedPreferences.getInstance();
      await p.setBool(_cleEcho, annulationEcho);
      await p.setBool(_cleBruit, reductionBruit);
      await p.setBool(_cleGain, gainAuto);
      await p.setBool(_cleTelephone, traitementTelephone);
    } catch (_) {}
  }

  static Future<void> reinitialiser() async {
    annulationEcho = false;
    reductionBruit = false;
    gainAuto = false;
    traitementTelephone = false;
    await enregistrer();
  }

  static bool get parDefaut =>
      !annulationEcho && !reductionBruit && !gainAuto && !traitementTelephone;

  /// Transmet les réglages au moteur de connexion VDO.Ninja.
  static void _appliquer() {
    sig.rgProAudio = true;
    sig.rgAnnulationEcho = annulationEcho;
    sig.rgReductionBruit = reductionBruit;
    sig.rgGainAuto = gainAuto;
  }
}
