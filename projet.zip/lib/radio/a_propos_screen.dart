import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import 'theme.dart';
import 'version.dart';

/// Adresse du code source de l'appli (obligation de la licence GPL v3).
const String urlCodeSource =
    'https://github.com/loic-T/radio-geniale-correspondant';
const String _urlProjetOrigine = 'https://github.com/steveseguin/vdon_flutter';
const String _urlGpl = 'https://www.gnu.org/licenses/gpl-3.0.html';

/// Écran « À propos » : crédits, licence et mentions légales.
class AProposScreen extends StatelessWidget {
  const AProposScreen({super.key});

  Future<void> _ouvrir(BuildContext context, String url) async {
    bool ok = false;
    try {
      ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (_) {}
    if (!ok && context.mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Lien : $url')));
    }
  }

  @override
  Widget build(BuildContext context) {
    const texte = TextStyle(color: RgColors.texte, fontSize: 15, height: 1.4);
    const titre = TextStyle(
        color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold);

    Widget lien(String libelle, String url) => Align(
          alignment: Alignment.centerLeft,
          child: TextButton.icon(
            onPressed: () => _ouvrir(context, url),
            style: TextButton.styleFrom(
                foregroundColor: RgColors.texte, padding: EdgeInsets.zero),
            icon: const Icon(Icons.open_in_new, size: 18),
            label: Text(libelle,
                style: const TextStyle(decoration: TextDecoration.underline)),
          ),
        );

    return Scaffold(
      appBar: AppBar(
        backgroundColor: RgColors.fond,
        foregroundColor: RgColors.texte,
        elevation: 0,
        title: const Text('À propos'),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
          children: [
            Image.asset('assets/logo.png', height: 90),
            const SizedBox(height: 8),
            Text('Radio Géniale – $libelleVersion',
                textAlign: TextAlign.center, style: texte),
            const SizedBox(height: 24),
            const Text('Basée sur VDO.Ninja', style: titre),
            const SizedBox(height: 6),
            const Text(
              'Cette appli est une version modifiée de VDO.Ninja Flutter, '
              'l\'application open source de Steve Seguin '
              '(© Steve Seguin et contributeurs). VDO.Ninja est une marque '
              'de son auteur ; Radio Géniale n\'est pas affiliée au projet.',
              style: texte,
            ),
            lien('Projet d\'origine (VDO.Ninja Flutter)', _urlProjetOrigine),
            const SizedBox(height: 16),
            const Text('Licence', style: titre),
            const SizedBox(height: 6),
            const Text(
              'Cette appli est un logiciel libre, distribué sous licence GNU '
              'GPL version 3. Vous pouvez la redistribuer et la modifier '
              'selon les termes de cette licence.\n\n'
              'Elle est fournie SANS AUCUNE GARANTIE, ni explicite ni '
              'implicite, y compris de qualité marchande ou d\'adéquation à '
              'un usage particulier. Voir la licence pour plus de détails.',
              style: texte,
            ),
            lien('Texte de la licence GPL v3', _urlGpl),
            const SizedBox(height: 16),
            const Text('Code source', style: titre),
            const SizedBox(height: 6),
            const Text(
              'Le code source complet de cette appli, avec les modifications '
              'apportées par Radio Géniale, est disponible librement :',
              style: texte,
            ),
            lien('Code source de l\'appli', urlCodeSource),
            const SizedBox(height: 16),
            const Text('Bibliothèques utilisées', style: titre),
            const SizedBox(height: 6),
            const Text(
              'L\'appli utilise des composants open source (Flutter, WebRTC, '
              'encodeur MP3 LAME sous licence LGPL…), chacun sous sa propre '
              'licence.',
              style: texte,
            ),
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton.icon(
                onPressed: () => showLicensePage(
                  context: context,
                  applicationName: 'Radio Géniale',
                  applicationVersion: libelleVersion,
                  applicationLegalese:
                      'Basée sur VDO.Ninja Flutter © Steve Seguin – GPL v3',
                ),
                style: TextButton.styleFrom(
                    foregroundColor: RgColors.texte, padding: EdgeInsets.zero),
                icon: const Icon(Icons.description_outlined, size: 18),
                label: const Text('Voir les licences des bibliothèques',
                    style: TextStyle(decoration: TextDecoration.underline)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
