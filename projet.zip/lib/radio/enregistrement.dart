import 'dart:io' show Platform;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'micro.dart';
import 'theme.dart';

/// Enregistrement MP3 (mono 128 kb/s) du micro pendant le direct.
/// Android uniquement. Le fichier est toujours gardé sur le téléphone
/// (Musique › Radio Géniale) ; l'envoi à la radio est proposé à l'arrêt.
class Enregistrement {
  static const _canal = MethodChannel('radiogeniale/enregistrement');

  static bool get disponible => Platform.isAndroid;

  static String _deux(int n) => n.toString().padLeft(2, '0');

  static String nomFichier(String nom) {
    final d = DateTime.now();
    final propre = nom
        .replaceAll(RegExp(r'[^A-Za-z0-9À-ÿ_-]+'), '-')
        .replaceAll(RegExp(r'-+'), '-');
    return 'RadioGeniale_${propre}_${d.year}${_deux(d.month)}${_deux(d.day)}'
        '-${_deux(d.hour)}${_deux(d.minute)}${_deux(d.second)}.mp3';
  }

  static Future<bool> demarrer(String nom) async {
    try {
      return await _canal.invokeMethod<bool>(
              'demarrer', {'fichier': nomFichier(nom)}) ??
          false;
    } catch (_) {
      return false;
    }
  }

  /// Enregistrement sans direct : l'appli ouvre elle-même le micro, avec le
  /// micro et le mode choisis dans l'écran « Micro ».
  static Future<bool> demarrerAutonome(String nom) async {
    try {
      return await _canal.invokeMethod<bool>('demarrerAutonome', {
            'fichier': nomFichier(nom),
            'mode': ReglagesMicro.mode,
            'micro': ReglagesMicro.micro,
          }) ??
          false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> pause(bool pause) async {
    try {
      await _canal.invokeMethod('pause', {'pause': pause});
    } catch (_) {}
  }

  /// Arrête l'enregistrement. Renvoie null si rien n'a été enregistré.
  static Future<InfosEnregistrement?> arreter() async {
    try {
      final r = await _canal.invokeMethod<Map>('arreter');
      if (r == null || r['ok'] != true) return null;
      return InfosEnregistrement(
        nom: r['nom'] as String? ?? '',
        dureeSecondes: (r['duree'] as num?)?.toInt() ?? 0,
        octets: (r['octets'] as num?)?.toInt() ?? 0,
        visibleDansMusique: r['public'] == true,
      );
    } catch (_) {
      return null;
    }
  }

  /// mode : 'signal' ou 'mail'.
  static Future<bool> partager(
      String mode, String nom, InfosEnregistrement infos) async {
    try {
      return await _canal.invokeMethod<bool>('partager', {
            'mode': mode,
            'sujet': 'Enregistrement Radio Géniale – $nom',
            'texte': 'Enregistrement de $nom (${infos.duree}) : ${infos.nom}',
          }) ??
          false;
    } catch (_) {
      return false;
    }
  }
}

class InfosEnregistrement {
  InfosEnregistrement({
    required this.nom,
    required this.dureeSecondes,
    required this.octets,
    required this.visibleDansMusique,
  });

  final String nom;
  final int dureeSecondes;
  final int octets;
  final bool visibleDansMusique;

  String get duree {
    final m = dureeSecondes ~/ 60;
    final s = dureeSecondes % 60;
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  String get taille => '${(octets / (1024 * 1024)).toStringAsFixed(1)} Mo';
}

/// Fenêtre « Voulez-vous envoyer l'enregistrement à Radio Géniale ? ».
Future<void> proposerEnvoi(
    BuildContext context, String nom, InfosEnregistrement rec) async {
  final ou = rec.visibleDansMusique
      ? 'dans Musique › Radio Géniale'
      : 'dans les fichiers de l\'appli';
  final choix = await showDialog<String>(
    context: context,
    builder: (context) => AlertDialog(
      backgroundColor: RgColors.fondSecondaire,
      title: const Text('Enregistrement terminé',
          style: TextStyle(color: Colors.white)),
      content: Text(
        'Durée ${rec.duree} · ${rec.taille}\n'
        'Enregistré sur le téléphone, $ou.\n\n'
        'Voulez-vous envoyer l\'enregistrement à Radio Géniale ?',
        style: const TextStyle(color: Colors.white),
      ),
      actionsOverflowDirection: VerticalDirection.down,
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, 'non'),
          child: const Text('Garder sur le téléphone',
              style: TextStyle(color: Colors.white70)),
        ),
        TextButton(
          onPressed: () => Navigator.pop(context, 'mail'),
          child: const Text('Par mail',
              style:
                  TextStyle(color: RgColors.texte, fontWeight: FontWeight.bold)),
        ),
        TextButton(
          onPressed: () => Navigator.pop(context, 'signal'),
          child: const Text('Par Signal',
              style:
                  TextStyle(color: RgColors.texte, fontWeight: FontWeight.bold)),
        ),
      ],
    ),
  );
  if (choix == 'mail' || choix == 'signal') {
    final ok = await Enregistrement.partager(choix!, nom, rec);
    if (!ok && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Envoi impossible. Le fichier reste sur le '
              'téléphone.')));
    }
  }
}
