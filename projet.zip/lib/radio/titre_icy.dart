import 'dart:async';
import 'dart:convert';
import 'dart:io';

/// Lit le titre en cours (« StreamTitle ») dans les métadonnées ICY du flux,
/// comme le fait le site. Ouvre le flux, lit le premier bloc de
/// métadonnées puis referme la connexion. Renvoie null si indisponible.
Future<String?> lireTitreIcy(String url) async {
  final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
  try {
    final req = await client.getUrl(Uri.parse(url));
    req.headers.set('Icy-MetaData', '1');
    req.headers.set(HttpHeaders.userAgentHeader,
        'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/130.0 Mobile');
    final rep = await req.close().timeout(const Duration(seconds: 8));
    final metaint = int.tryParse(rep.headers.value('icy-metaint') ?? '');
    if (metaint == null || metaint <= 0) return null;

    final tampon = <int>[];
    int? longueurMeta;
    await for (final morceau
        in rep.timeout(const Duration(seconds: 10))) {
      tampon.addAll(morceau);
      if (longueurMeta == null && tampon.length > metaint) {
        longueurMeta = tampon[metaint] * 16;
        if (longueurMeta == 0) return null;
      }
      if (longueurMeta != null && tampon.length >= metaint + 1 + longueurMeta) {
        break;
      }
      if (tampon.length > metaint + 5000) break; // sécurité
    }
    if (longueurMeta == null || tampon.length < metaint + 1 + longueurMeta) {
      return null;
    }
    final octets = tampon
        .sublist(metaint + 1, metaint + 1 + longueurMeta)
        .where((b) => b != 0)
        .toList();
    String texte;
    try {
      texte = utf8.decode(octets);
    } catch (_) {
      texte = latin1.decode(octets);
    }
    final m = RegExp(r"StreamTitle='(.*?)';").firstMatch(texte);
    final titre = m?.group(1)?.trim();
    return (titre == null || titre.isEmpty) ? null : titre;
  } catch (_) {
    return null;
  } finally {
    client.close(force: true);
  }
}
