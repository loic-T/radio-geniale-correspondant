import 'dart:convert';
import 'dart:io' show Platform;

import 'package:http/http.dart' as http;

import 'version.dart';

/// Lien fixe vers le dernier APK publié sur GitHub.
const String urlDernierApk =
    'https://github.com/loic-T/radio-geniale-correspondant/releases/latest/download/RadioGeniale.apk';

const String _urlApiDerniereRelease =
    'https://api.github.com/repos/loic-T/radio-geniale-correspondant/releases/latest';

/// Nouvelle version disponible sur GitHub.
class MiseAJour {
  MiseAJour(this.version, this.url);
  final String version;
  final String url;
}

/// Vérifie s'il existe une version plus récente que celle installée.
/// Android uniquement. Renvoie null s'il n'y a rien de nouveau ou en cas
/// de problème (pas d'Internet, GitHub indisponible…).
Future<MiseAJour?> verifierMiseAJour() async {
  if (!Platform.isAndroid) return null;
  try {
    final rep = await http.get(
      Uri.parse(_urlApiDerniereRelease),
      headers: {'Accept': 'application/vnd.github+json'},
    ).timeout(const Duration(seconds: 8));
    if (rep.statusCode != 200) return null;

    final data = jsonDecode(rep.body) as Map<String, dynamic>;
    final tag = (data['tag_name'] as String? ?? '').trim();
    final distante = tag.startsWith('v') ? tag.substring(1) : tag;
    if (!_plusRecente(distante, versionApp)) return null;

    var url = urlDernierApk;
    final assets = data['assets'];
    if (assets is List) {
      for (final a in assets) {
        if (a is Map && a['name'] == 'RadioGeniale.apk') {
          url = (a['browser_download_url'] as String?) ?? url;
        }
      }
    }
    return MiseAJour(distante, url);
  } catch (_) {
    return null;
  }
}

/// true si la version [a] (ex. « 1.10.0 ») est plus récente que [b].
bool _plusRecente(String a, String b) {
  List<int> parties(String v) =>
      v.split('.').map((p) => int.tryParse(p.trim()) ?? 0).toList();
  final pa = parties(a), pb = parties(b);
  for (var i = 0; i < 3; i++) {
    final x = i < pa.length ? pa[i] : 0;
    final y = i < pb.length ? pb[i] : 0;
    if (x != y) return x > y;
  }
  return false;
}
