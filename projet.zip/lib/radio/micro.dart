import 'dart:io' show Platform;

import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../src/call_sample/signaling.dart' as sig;

/// Un mode d'ouverture du micro proposé par Android.
class ModeMicro {
  const ModeMicro(this.cle, this.nom, this.description);
  final String cle;
  final String nom;
  final String description;
}

const List<ModeMicro> modesMicro = [
  ModeMicro('mic', 'Brut (mono)',
      'Son du micro sans traitement de l\'appli, un seul micro. Réglage par défaut.'),
  ModeMicro('unprocessed', 'Non traité',
      'Aucun traitement du téléphone, si le téléphone le permet. Souvent plus faible.'),
  ModeMicro('camcorder', 'Vidéo / ambiance',
      'Le mode utilisé pour filmer : souvent le micro arrière, prise de son d\'ensemble.'),
  ModeMicro('voiceRecognition', 'Dictée',
      'Réglé pour une voix proche du téléphone, en général le micro du bas.'),
  ModeMicro('voiceCommunication', 'Appel',
      'Comme un appel téléphonique : réduction de bruit (effet « noise gate »).'),
  ModeMicro('micStereo', 'Brut stéréo (ancien réglage)',
      'Le réglage des versions 1.5 à 1.9 : peut mélanger deux micros.'),
];

/// Réglages du micro du correspondant, mémorisés sur le téléphone.
class ReglagesMicro {
  static const _cleMode = 'rg_micro_mode';
  static const _cleDevice = 'rg_micro_device';
  static const _cleHD = 'rg_audio_hd';

  /// Mode choisi (pris en compte au prochain lancement de l'appli).
  static String mode = 'mic';

  /// Mode réellement utilisé depuis le lancement en cours.
  static String modeActif = 'mic';

  /// Micro physique choisi (identifiant Android), null = automatique.
  static String? micro;

  /// Qualité HD (64 kb/s) au lieu de STD (32 kb/s).
  static bool hd = false;

  static bool get disponible => Platform.isAndroid;

  static Future<void> charger() async {
    try {
      final p = await SharedPreferences.getInstance();
      mode = p.getString(_cleMode) ?? 'mic';
      if (!modesMicro.any((m) => m.cle == mode)) mode = 'mic';
      micro = p.getString(_cleDevice);
      hd = p.getBool(_cleHD) ?? false;
    } catch (_) {}
    modeActif = mode;
    sig.rgDebitAudioKbps = hd ? 64 : 32;
  }

  static Future<void> _sauver() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString(_cleMode, mode);
      if (micro == null) {
        await p.remove(_cleDevice);
      } else {
        await p.setString(_cleDevice, micro!);
      }
      await p.setBool(_cleHD, hd);
    } catch (_) {}
  }

  static Future<void> choisirMode(String cle) async {
    mode = cle;
    await _sauver();
  }

  /// Choisit le micro physique ; appliqué tout de suite (même en direct).
  static Future<void> choisirMicro(String? deviceId) async {
    micro = deviceId;
    await _sauver();
    await appliquerMicro();
  }

  static Future<void> appliquerMicro() async {
    final id = micro;
    if (!disponible || id == null) return;
    try {
      await Helper.selectAudioInput(id);
    } catch (_) {}
  }

  static Future<void> choisirHD(bool valeur) async {
    hd = valeur;
    sig.rgDebitAudioKbps = valeur ? 64 : 32;
    await _sauver();
  }

  /// Micros intégrés et filaires déclarés par Android.
  static Future<List<MediaDeviceInfo>> listerMicros() async {
    if (!disponible) return [];
    try {
      final tous = await navigator.mediaDevices.enumerateDevices();
      return tous.where((d) => d.kind == 'audioinput').toList();
    } catch (_) {
      return [];
    }
  }

  /// Nom lisible d'un micro (« Micro du bas », « Micro arrière »…).
  static String nomMicro(MediaDeviceInfo d) {
    final l = d.label;
    final bas = l.toLowerCase();
    String? position;
    if (bas.contains('bottom')) position = 'Micro du bas';
    if (bas.contains('back')) position = 'Micro arrière';
    if (bas.contains('top')) position = 'Micro du haut';
    if (bas.contains('front')) position = 'Micro avant';
    if (bas.contains('headset')) return 'Micro du casque / kit filaire';
    if (position != null) return '$position  ($l)';
    return l.isEmpty ? 'Micro ${d.deviceId}' : l;
  }
}
