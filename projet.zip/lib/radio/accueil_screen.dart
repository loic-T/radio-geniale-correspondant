import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import 'lecteur_radio.dart';
import 'login_screen.dart';
import 'theme.dart';
import 'version.dart';

const String emailContact = 'radiogeniale@proton.me';

/// Page d'accueil : reprend radiogeniale.neocities.org (logo, écoute du
/// direct, contact) avec en plus l'accès à l'interface correspondant.
class AccueilScreen extends StatelessWidget {
  const AccueilScreen({super.key});

  Future<void> _ouvrirCorrespondant(BuildContext context) async {
    final lecteur = LecteurRadio.instance;
    final etaitActif = lecteur.actif;
    // On coupe toujours la radio : sinon le son du haut-parleur repartirait
    // dans le micro (effet larsen / écho à l'antenne).
    await lecteur.arreter();
    if (etaitActif) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Radio coupée pour éviter l\'écho dans le micro.'),
        ));
      }
    }
    if (!context.mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const LoginScreen()),
    );
  }

  Future<void> _ecrire(BuildContext context) async {
    final uri = Uri(scheme: 'mailto', path: emailContact);
    bool ok = false;
    try {
      ok = await launchUrl(uri);
    } catch (_) {}
    if (!ok && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Aucune appli mail trouvée. Écrivez-nous à $emailContact'),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 520),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Image.asset('assets/logo.png', fit: BoxFit.contain),
                        const SizedBox(height: 32),
                        const _ZoneLecteur(),
                        const SizedBox(height: 32),
                        _BlocContact(onEcrire: () => _ecrire(context)),
                        const SizedBox(height: 32),
                        OutlinedButton.icon(
                          onPressed: () => _ouvrirCorrespondant(context),
                          icon: const Icon(Icons.mic),
                          label: const Text('ACCÈS CORRESPONDANT'),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: RgColors.texte,
                            side: const BorderSide(
                                color: RgColors.texte, width: 2),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 24, vertical: 18),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(50)),
                            textStyle: const TextStyle(
                                fontSize: 17, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            // Pied de page, comme sur le site
            Container(
              width: double.infinity,
              color: RgColors.fondSecondaire,
              padding: EdgeInsets.fromLTRB(
                  16, 14, 16, 14 + MediaQuery.of(context).padding.bottom),
              child: Row(
                children: [
                  const Expanded(
                    child: Text(
                      '© Radio Géniale 2026',
                      style: TextStyle(color: Colors.white, fontSize: 15),
                    ),
                  ),
                  Text(
                    libelleVersion,
                    style: const TextStyle(color: Colors.white70, fontSize: 13),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Lecteur du direct : carte dégradée aux couleurs de la radio, gros bouton
/// lecture/arrêt avec ondes animées, titre de l'émission et égaliseur.
class _ZoneLecteur extends StatefulWidget {
  const _ZoneLecteur();

  @override
  State<_ZoneLecteur> createState() => _ZoneLecteurState();
}

class _ZoneLecteurState extends State<_ZoneLecteur>
    with SingleTickerProviderStateMixin {
  late final AnimationController _anim = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1600),
  );
  final LecteurRadio _lecteur = LecteurRadio.instance;

  @override
  void initState() {
    super.initState();
    _lecteur.addListener(_majAnimation);
    _majAnimation();
  }

  void _majAnimation() {
    if (_lecteur.etat == EtatLecteur.lecture) {
      if (!_anim.isAnimating) _anim.repeat();
    } else {
      _anim.stop();
      _anim.value = 0;
    }
  }

  @override
  void dispose() {
    _lecteur.removeListener(_majAnimation);
    _anim.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: _lecteur,
      builder: (context, _) {
        final etat = _lecteur.etat;
        final actif = _lecteur.actif;
        final enLecture = etat == EtatLecteur.lecture;

        final String statut;
        switch (etat) {
          case EtatLecteur.arrete:
            statut = 'Touchez pour écouter le direct';
            break;
          case EtatLecteur.chargement:
            statut = 'Connexion au direct…';
            break;
          case EtatLecteur.lecture:
            statut = 'À l\'écoute';
            break;
          case EtatLecteur.erreur:
            statut = 'Direct indisponible pour le moment';
            break;
        }

        return Container(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 24),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [RgColors.fondTertiaire, RgColors.fondSecondaire],
            ),
            boxShadow: const [
              BoxShadow(
                  color: Colors.black38, blurRadius: 18, offset: Offset(0, 8)),
            ],
          ),
          child: Column(
            children: [
              Row(
                children: [
                  _Badge(enDirect: enLecture, anim: _anim),
                  const Spacer(),
                  if (enLecture) _Egaliseur(anim: _anim),
                ],
              ),
              const SizedBox(height: 20),
              _BoutonLecture(
                actif: actif,
                chargement: etat == EtatLecteur.chargement,
                anim: _anim,
                onTap: actif ? _lecteur.arreter : _lecteur.ecouter,
              ),
              const SizedBox(height: 20),
              Text(
                _lecteur.titre ?? 'Radio Géniale',
                textAlign: TextAlign.center,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 19,
                  fontWeight: FontWeight.bold,
                  height: 1.25,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                statut,
                textAlign: TextAlign.center,
                style: const TextStyle(color: RgColors.texte, fontSize: 14),
              ),
              if (etat == EtatLecteur.erreur) ...[
                const SizedBox(height: 8),
                SelectableText(
                  'Détail : ${_lecteur.derniereErreur ?? 'aucun'}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white60, fontSize: 11),
                ),
              ],
            ],
          ),
        );
      },
    );
  }
}

/// Pastille « EN DIRECT » (point rouge qui pulse pendant l'écoute).
class _Badge extends StatelessWidget {
  const _Badge({required this.enDirect, required this.anim});

  final bool enDirect;
  final Animation<double> anim;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.25),
        borderRadius: BorderRadius.circular(50),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimatedBuilder(
            animation: anim,
            builder: (context, _) {
              final t = enDirect ? (0.5 + 0.5 * (1 - (anim.value * 2 - 1).abs())) : 1.0;
              return Container(
                width: 9,
                height: 9,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: (enDirect ? Colors.redAccent : Colors.white54)
                      .withValues(alpha: t),
                ),
              );
            },
          ),
          const SizedBox(width: 8),
          Text(
            enDirect ? 'EN DIRECT' : 'LE DIRECT',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.5,
            ),
          ),
        ],
      ),
    );
  }
}

/// Gros bouton rond lecture / arrêt, entouré d'ondes pendant l'écoute.
class _BoutonLecture extends StatelessWidget {
  const _BoutonLecture({
    required this.actif,
    required this.chargement,
    required this.anim,
    required this.onTap,
  });

  final bool actif;
  final bool chargement;
  final Animation<double> anim;
  final VoidCallback onTap;

  static const double _taille = 116;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: _taille * 1.7,
      height: _taille * 1.7,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Ondes concentriques
          AnimatedBuilder(
            animation: anim,
            builder: (context, _) => CustomPaint(
              size: const Size(_taille * 1.7, _taille * 1.7),
              painter: _Ondes(progression: anim.value, rayonBase: _taille / 2),
            ),
          ),
          Material(
            color: RgColors.texte,
            shape: const CircleBorder(),
            elevation: 10,
            shadowColor: Colors.black54,
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: onTap,
              child: SizedBox(
                width: _taille,
                height: _taille,
                child: Center(
                  child: chargement
                      ? const SizedBox(
                          width: 44,
                          height: 44,
                          child: CircularProgressIndicator(
                              strokeWidth: 4, color: RgColors.fond),
                        )
                      : Icon(
                          actif ? Icons.stop_rounded : Icons.play_arrow_rounded,
                          size: 72,
                          color: RgColors.fond,
                        ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Ondes extends CustomPainter {
  _Ondes({required this.progression, required this.rayonBase});

  final double progression;
  final double rayonBase;

  @override
  void paint(Canvas canvas, Size size) {
    if (progression == 0) return;
    final centre = size.center(Offset.zero);
    final maxExtra = size.width / 2 - rayonBase;
    for (var i = 0; i < 3; i++) {
      final p = (progression + i / 3) % 1.0;
      final paint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..color = RgColors.texte.withValues(alpha: (1 - p) * 0.6);
      canvas.drawCircle(centre, rayonBase + maxExtra * p, paint);
    }
  }

  @override
  bool shouldRepaint(_Ondes old) => old.progression != progression;
}

/// Petit égaliseur animé (barres qui dansent pendant l'écoute).
class _Egaliseur extends StatelessWidget {
  const _Egaliseur({required this.anim});

  final Animation<double> anim;

  @override
  Widget build(BuildContext context) {
    const phases = [0.0, 0.35, 0.7, 0.15, 0.55];
    return AnimatedBuilder(
      animation: anim,
      builder: (context, _) => Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          for (final ph in phases)
            Container(
              width: 4,
              height: 6 + 14 * (0.5 + 0.5 * math.sin((anim.value + ph) * 2 * math.pi * 2)),
              margin: const EdgeInsets.symmetric(horizontal: 1.5),
              decoration: BoxDecoration(
                color: RgColors.texte,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
        ],
      ),
    );
  }
}

class _BlocContact extends StatelessWidget {
  const _BlocContact({required this.onEcrire});

  final VoidCallback onEcrire;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Contact',
          style: TextStyle(
              color: RgColors.texte, fontSize: 22, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        const Text(
          'Une remarque ? Une question ? Contactez-nous par mail :',
          style: TextStyle(
              color: RgColors.texte, fontSize: 16, fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 4),
        InkWell(
          onTap: onEcrire,
          child: const Padding(
            padding: EdgeInsets.symmetric(vertical: 6),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.mail_outline, color: RgColors.texte),
                SizedBox(width: 8),
                Text(
                  emailContact,
                  style: TextStyle(
                    color: RgColors.texte,
                    fontSize: 16,
                    fontStyle: FontStyle.italic,
                    decoration: TextDecoration.underline,
                    decorationColor: RgColors.texte,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
