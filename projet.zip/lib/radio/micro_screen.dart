import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';

import 'micro.dart';
import 'theme.dart';

/// Écran « Micro » : choix du micro physique, du mode Android et de la
/// qualité (STD / HD).
class MicroScreen extends StatefulWidget {
  const MicroScreen({super.key, this.pendantDirect = false});

  /// Ouvert depuis l'écran de direct.
  final bool pendantDirect;

  @override
  State<MicroScreen> createState() => _MicroScreenState();
}

class _MicroScreenState extends State<MicroScreen> {
  List<MediaDeviceInfo> _micros = [];
  bool _chargement = true;

  @override
  void initState() {
    super.initState();
    ReglagesMicro.listerMicros().then((l) {
      if (mounted) {
        setState(() {
          _micros = l;
          _chargement = false;
        });
      }
    });
  }

  Widget _section(String titre) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 4),
        child: Text(titre.toUpperCase(),
            style: const TextStyle(
                color: RgColors.fondTertiaire,
                fontSize: 13,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.2)),
      );

  Widget _note(String texte, {Color couleur = Colors.white70}) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 2, 16, 6),
        child: Text(texte, style: TextStyle(color: couleur, fontSize: 13)),
      );

  Widget _choix({
    required String titre,
    String? sousTitre,
    required bool selectionne,
    required VoidCallback onTap,
  }) {
    return ListTile(
      onTap: onTap,
      leading: Icon(
        selectionne ? Icons.radio_button_checked : Icons.radio_button_off,
        color: RgColors.texte,
      ),
      title: Text(titre,
          style: TextStyle(
              color: RgColors.texte,
              fontWeight: selectionne ? FontWeight.bold : FontWeight.normal)),
      subtitle: sousTitre == null
          ? null
          : Text(sousTitre,
              style: const TextStyle(color: Colors.white60, fontSize: 12.5)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final redemarrer = ReglagesMicro.mode != ReglagesMicro.modeActif;
    final android = ReglagesMicro.disponible;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: RgColors.fond,
        foregroundColor: RgColors.texte,
        elevation: 0,
        title: const Text('Micro'),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: 24),
          children: [
            // ---- Qualité ----
            _section('Qualité du son envoyé'),
            SwitchListTile(
              value: ReglagesMicro.hd,
              onChanged: (v) async {
                await ReglagesMicro.choisirHD(v);
                setState(() {});
              },
              title: Text(ReglagesMicro.hd ? 'HD (64 kb/s)' : 'STD (32 kb/s)',
                  style: const TextStyle(
                      color: RgColors.texte, fontWeight: FontWeight.bold)),
              subtitle: const Text(
                  'HD : son plus riche, demande une bonne connexion. '
                  'STD : recommandé en 4G faible.',
                  style: TextStyle(color: Colors.white60, fontSize: 12.5)),
            ),

            if (!android) ...[
              _section('Micro'),
              _note('Le choix du micro et du mode n\'est disponible que '
                  'sur Android.'),
            ],

            if (android) ...[
              // ---- Micro physique ----
              _section('Micro utilisé'),
              _note('Les micros que votre téléphone déclare. Le changement '
                  's\'applique tout de suite.'),
              if (_chargement)
                const Padding(
                  padding: EdgeInsets.all(16),
                  child: Center(
                      child: CircularProgressIndicator(color: RgColors.texte)),
                )
              else ...[
                _choix(
                  titre: 'Automatique (choix d\'Android)',
                  selectionne: ReglagesMicro.micro == null,
                  onTap: () async {
                    await ReglagesMicro.choisirMicro(null);
                    setState(() {});
                  },
                ),
                for (final m in _micros)
                  _choix(
                    titre: ReglagesMicro.nomMicro(m),
                    selectionne: ReglagesMicro.micro == m.deviceId,
                    onTap: () async {
                      await ReglagesMicro.choisirMicro(m.deviceId);
                      setState(() {});
                    },
                  ),
                if (_micros.length <= 1)
                  _note('Votre téléphone ne déclare qu\'un seul micro : '
                      'essayez plutôt de changer de mode ci-dessous.'),
                if (ReglagesMicro.micro == null)
                  _note('Si un micro précis était choisi avant, le retour en '
                      'automatique s\'applique au prochain lancement.'),
              ],

              // ---- Mode Android ----
              _section('Mode du micro'),
              _note('La façon dont Android traite le son. Pris en compte au '
                  'prochain lancement de l\'appli.'),
              for (final m in modesMicro)
                _choix(
                  titre: m.nom,
                  sousTitre: m.description,
                  selectionne: ReglagesMicro.mode == m.cle,
                  onTap: () async {
                    await ReglagesMicro.choisirMode(m.cle);
                    setState(() {});
                  },
                ),
              if (redemarrer)
                _note(
                    widget.pendantDirect
                        ? '⚠ Terminez d\'abord le direct, puis fermez '
                            'complètement l\'appli (balayez-la dans les '
                            'applis récentes) et rouvrez-la pour appliquer '
                            'ce mode.'
                        : '⚠ Fermez complètement l\'appli (balayez-la dans '
                            'les applis récentes) puis rouvrez-la pour '
                            'appliquer ce mode.',
                    couleur: Colors.amberAccent),
            ],
          ],
        ),
      ),
    );
  }
}
