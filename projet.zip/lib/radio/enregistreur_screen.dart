import 'dart:async';
import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';

import 'arriere_plan.dart';
import 'enregistrement.dart';
import 'lecteur_radio.dart';
import 'micro.dart';
import 'micro_screen.dart';
import 'theme.dart';

/// Enregistrement sans direct (Android) : MP3 mono 128 kb/s, sans connexion
/// à la régie. Même micro et même mode que le direct.
class EnregistreurScreen extends StatefulWidget {
  const EnregistreurScreen({super.key, required this.nom});

  final String nom;

  @override
  State<EnregistreurScreen> createState() => _EnregistreurScreenState();
}

class _EnregistreurScreenState extends State<EnregistreurScreen> {
  /// Boutons de la notification (Pause / Arrêter).
  static const _canalNotif = MethodChannel('radiogeniale/direct');

  bool _enregistre = false;
  bool _pause = false;
  bool _demarrage = false;
  int _secondes = 0;
  Timer? _minuteur;

  @override
  void initState() {
    super.initState();
    _canalNotif.setMethodCallHandler((call) async {
      if (!mounted) return null;
      if (call.method == 'basculer') {
        await _basculerPause();
      } else if (call.method == 'terminer') {
        await _arreter();
      }
      return null;
    });
  }

  @override
  void dispose() {
    _minuteur?.cancel();
    _canalNotif.setMethodCallHandler(null);
    if (_enregistre) {
      // Sortie forcée : le fichier est gardé sur le téléphone.
      Enregistrement.arreter();
      ArrierePlan.arreter();
    }
    super.dispose();
  }

  Future<void> _demarrer() async {
    if (_demarrage || _enregistre) return;
    setState(() => _demarrage = true);

    final micro = await Permission.microphone.request();
    if (!micro.isGranted) {
      if (!mounted) return;
      setState(() => _demarrage = false);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('L\'appli a besoin du micro pour enregistrer.')));
      return;
    }
    await Permission.notification.request();
    await LecteurRadio.instance.arreter();

    // Garde le micro actif écran verrouillé (notification « Enregistrement »).
    await ArrierePlan.demarrer(nom: widget.nom, enregistrementSeul: true);
    final ok = await Enregistrement.demarrerAutonome(widget.nom);
    if (!mounted) return;
    if (!ok) {
      await ArrierePlan.arreter();
      setState(() => _demarrage = false);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Micro inaccessible. Il est peut-être utilisé par '
              'une autre appli.')));
      return;
    }
    setState(() {
      _demarrage = false;
      _enregistre = true;
      _pause = false;
      _secondes = 0;
    });
    _minuteur = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_enregistre && !_pause && mounted) setState(() => _secondes++);
    });
  }

  Future<void> _basculerPause() async {
    if (!_enregistre) return;
    final p = !_pause;
    await Enregistrement.pause(p);
    await ArrierePlan.majNotification(nom: widget.nom, muet: p);
    if (mounted) setState(() => _pause = p);
  }

  Future<void> _arreter() async {
    if (!_enregistre) return;
    _minuteur?.cancel();
    setState(() => _enregistre = false);
    final rec = await Enregistrement.arreter();
    await ArrierePlan.arreter();
    if (!mounted) return;
    if (rec == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Rien n\'a été enregistré.')));
      return;
    }
    await proposerEnvoi(context, widget.nom, rec);
  }

  Future<void> _confirmerSortie() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: RgColors.fondSecondaire,
        title: const Text('Arrêter l\'enregistrement ?',
            style: TextStyle(color: Colors.white)),
        content: const Text(
            'L\'enregistrement sera arrêté et gardé sur le téléphone.',
            style: TextStyle(color: Colors.white)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Continuer',
                style: TextStyle(color: Colors.white)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Arrêter',
                style: TextStyle(
                    color: RgColors.texte, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
    if (ok == true) {
      await _arreter();
      if (mounted) Navigator.of(context).pop();
    }
  }

  String get _temps {
    String deux(int n) => n.toString().padLeft(2, '0');
    final h = _secondes ~/ 3600, m = (_secondes ~/ 60) % 60, s = _secondes % 60;
    return h > 0 ? '$h:${deux(m)}:${deux(s)}' : '${deux(m)}:${deux(s)}';
  }

  @override
  Widget build(BuildContext context) {
    final mode = modesMicro.firstWhere((m) => m.cle == ReglagesMicro.mode,
        orElse: () => modesMicro.first);

    return PopScope(
      canPop: !_enregistre,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _confirmerSortie();
      },
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: RgColors.fond,
          foregroundColor: RgColors.texte,
          elevation: 0,
          title: const Text('Enregistrement sans direct'),
          actions: [
            if (!_enregistre)
              IconButton(
                tooltip: 'Micro',
                icon: const Icon(Icons.settings_voice),
                onPressed: () async {
                  await Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => const MicroScreen()));
                  if (mounted) setState(() {});
                },
              ),
          ],
        ),
        body: SafeArea(
          child: LayoutBuilder(builder: (context, c) {
            final taille =
                (c.maxHeight * 0.32).clamp(110.0, 200.0).toDouble();
            return Column(
              children: [
                const SizedBox(height: 12),
                Text(widget.nom,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        color: RgColors.texte,
                        fontSize: 20,
                        fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text('MP3 mono 128 kb/s · mode ${mode.nom}',
                    style:
                        const TextStyle(color: Colors.white60, fontSize: 13)),
                Expanded(
                  child: Center(
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            _enregistre
                                ? (_pause ? 'EN PAUSE' : '● ENREGISTREMENT')
                                : 'Prêt à enregistrer',
                            style: TextStyle(
                              color: _enregistre
                                  ? (_pause
                                      ? Colors.amberAccent
                                      : Colors.redAccent)
                                  : RgColors.texte,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.2,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            _temps,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 44,
                              fontWeight: FontWeight.w300,
                              fontFeatures: [FontFeature.tabularFigures()],
                            ),
                          ),
                          const SizedBox(height: 24),
                          SizedBox(
                            width: taille,
                            height: taille,
                            child: ElevatedButton(
                              onPressed: _demarrage
                                  ? null
                                  : (_enregistre ? _arreter : _demarrer),
                              style: ElevatedButton.styleFrom(
                                shape: const CircleBorder(),
                                padding: EdgeInsets.zero,
                                backgroundColor: _enregistre
                                    ? RgColors.texte
                                    : Colors.red.shade700,
                                foregroundColor: _enregistre
                                    ? RgColors.fond
                                    : Colors.white,
                                elevation: 8,
                              ),
                              child: _demarrage
                                  ? const CircularProgressIndicator(
                                      color: Colors.white)
                                  : Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(
                                            _enregistre
                                                ? Icons.stop_rounded
                                                : Icons.fiber_manual_record,
                                            size: taille * 0.36),
                                        Text(
                                          _enregistre ? 'STOP' : 'ENREGISTRER',
                                          style: TextStyle(
                                              fontSize: taille * 0.09,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ],
                                    ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          if (_enregistre)
                            OutlinedButton.icon(
                              onPressed: _basculerPause,
                              icon: Icon(_pause ? Icons.play_arrow : Icons.pause),
                              label: Text(_pause ? 'REPRENDRE' : 'PAUSE'),
                              style: OutlinedButton.styleFrom(
                                foregroundColor: RgColors.texte,
                                side: const BorderSide(color: RgColors.texte),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 28, vertical: 14),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(50)),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.fromLTRB(24, 0, 24, 16),
                  child: Text(
                    'Aucune connexion à la régie. À l\'arrêt, le fichier est '
                    'gardé sur le téléphone et l\'appli propose de l\'envoyer '
                    'à Radio Géniale.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white60, fontSize: 13),
                  ),
                ),
              ],
            );
          }),
        ),
      ),
    );
  }
}
